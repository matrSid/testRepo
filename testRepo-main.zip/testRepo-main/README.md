# calculators that calculate stuff like 1+2 and 1-2 its pretty cool
